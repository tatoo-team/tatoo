package fr.umlv.tatoo.cc.parser.parser;

public interface BranchTableActionDecl extends ActionDecl {
  //marker interface
}
