package fr.umlv.tatoo.cc.parser.parser;

public interface RegularTableActionDecl extends ActionDecl{
  boolean isError();
  // marker interface
}
