package fr.umlv.tatoo.cc.parser.table;

@SuppressWarnings("serial")
public class FatalConflictException extends RuntimeException {
  public FatalConflictException(String message) {
    super(message);
  }
}
