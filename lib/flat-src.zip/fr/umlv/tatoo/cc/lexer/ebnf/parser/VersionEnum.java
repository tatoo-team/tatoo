package fr.umlv.tatoo.cc.lexer.ebnf.parser;

/** 
 *  This class is generated - please do not edit it 
 */
public enum VersionEnum {
  DEFAULT
;
}