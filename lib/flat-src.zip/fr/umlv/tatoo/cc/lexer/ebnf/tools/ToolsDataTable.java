package fr.umlv.tatoo.cc.lexer.ebnf.tools;

import fr.umlv.tatoo.runtime.tools.ToolsTable;

import java.util.EnumMap;
import java.util.EnumSet;

import fr.umlv.tatoo.cc.lexer.ebnf.lexer.RuleEnum;
import fr.umlv.tatoo.cc.lexer.ebnf.parser.TerminalEnum;

public class ToolsDataTable {
  public static ToolsTable<RuleEnum,TerminalEnum> createToolsTable() {
      EnumSet<RuleEnum> spawns = EnumSet.of(RuleEnum.directivesdecl,RuleEnum.star,RuleEnum.lsqbracket,RuleEnum.comment,RuleEnum.versionsdecl,RuleEnum.attributesdecl,RuleEnum.rsqbracket,RuleEnum.slash,RuleEnum.productionsdecl,RuleEnum.commentsdecl,RuleEnum.quote,RuleEnum.rpar,RuleEnum.id,RuleEnum.importsdecl,RuleEnum.lpar,RuleEnum.lbracket,RuleEnum.startsdecl,RuleEnum.prioritiesdecl,RuleEnum.qmark,RuleEnum.semicolon,RuleEnum.regexquote,RuleEnum.blanksdecl,RuleEnum.plus,RuleEnum.errordecl,RuleEnum.quoted_name,RuleEnum.colon,RuleEnum.tokensdecl,RuleEnum.doublequote,RuleEnum.pipe,RuleEnum.assign,RuleEnum.eof,RuleEnum.rbracket,RuleEnum.regexdoublequote,RuleEnum.typesdecl,RuleEnum.branchesdecl,RuleEnum.assoc,RuleEnum.number,RuleEnum.qualifiedid,RuleEnum.dollar);
      EnumSet<RuleEnum> discards = EnumSet.allOf(RuleEnum.class);
      EnumMap<RuleEnum,TerminalEnum> terminal = new EnumMap<RuleEnum,TerminalEnum>(RuleEnum.class);
              terminal.put(RuleEnum.directivesdecl,TerminalEnum.directivesdecl);
              terminal.put(RuleEnum.star,TerminalEnum.star);
              terminal.put(RuleEnum.attributesdecl,TerminalEnum.attributesdecl);
              terminal.put(RuleEnum.versionsdecl,TerminalEnum.versionsdecl);
              terminal.put(RuleEnum.lsqbracket,TerminalEnum.lsqbracket);
              terminal.put(RuleEnum.slash,TerminalEnum.slash);
              terminal.put(RuleEnum.rsqbracket,TerminalEnum.rsqbracket);
              terminal.put(RuleEnum.productionsdecl,TerminalEnum.productionsdecl);
              terminal.put(RuleEnum.commentsdecl,TerminalEnum.commentsdecl);
              terminal.put(RuleEnum.quote,TerminalEnum.quote);
              terminal.put(RuleEnum.rpar,TerminalEnum.rpar);
              terminal.put(RuleEnum.id,TerminalEnum.id);
              terminal.put(RuleEnum.importsdecl,TerminalEnum.importsdecl);
              terminal.put(RuleEnum.lpar,TerminalEnum.lpar);
              terminal.put(RuleEnum.lbracket,TerminalEnum.lbracket);
              terminal.put(RuleEnum.startsdecl,TerminalEnum.startsdecl);
              terminal.put(RuleEnum.prioritiesdecl,TerminalEnum.prioritiesdecl);
              terminal.put(RuleEnum.qmark,TerminalEnum.qmark);
              terminal.put(RuleEnum.semicolon,TerminalEnum.semicolon);
              terminal.put(RuleEnum.regexquote,TerminalEnum.regexquote);
              terminal.put(RuleEnum.blanksdecl,TerminalEnum.blanksdecl);
              terminal.put(RuleEnum.plus,TerminalEnum.plus);
              terminal.put(RuleEnum.errordecl,TerminalEnum.errordecl);
              terminal.put(RuleEnum.colon,TerminalEnum.colon);
              terminal.put(RuleEnum.quoted_name,TerminalEnum.quoted_name);
              terminal.put(RuleEnum.tokensdecl,TerminalEnum.tokensdecl);
              terminal.put(RuleEnum.doublequote,TerminalEnum.doublequote);
              terminal.put(RuleEnum.pipe,TerminalEnum.pipe);
              terminal.put(RuleEnum.assign,TerminalEnum.assign);
              terminal.put(RuleEnum.eof,TerminalEnum.eof);
              terminal.put(RuleEnum.rbracket,TerminalEnum.rbracket);
              terminal.put(RuleEnum.typesdecl,TerminalEnum.typesdecl);
              terminal.put(RuleEnum.regexdoublequote,TerminalEnum.regexdoublequote);
              terminal.put(RuleEnum.branchesdecl,TerminalEnum.branchesdecl);
              terminal.put(RuleEnum.assoc,TerminalEnum.assoc);
              terminal.put(RuleEnum.number,TerminalEnum.number);
              terminal.put(RuleEnum.qualifiedid,TerminalEnum.qualifiedid);
              terminal.put(RuleEnum.dollar,TerminalEnum.dollar);
            EnumSet<RuleEnum> unconditionals = EnumSet.of(RuleEnum.comment,RuleEnum.space);
      return new ToolsTable<RuleEnum,TerminalEnum>(spawns,discards,unconditionals,terminal);
  }
}