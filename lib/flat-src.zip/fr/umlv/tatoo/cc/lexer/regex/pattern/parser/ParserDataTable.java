package fr.umlv.tatoo.cc.lexer.regex.pattern.parser;

import fr.umlv.tatoo.cc.lexer.regex.pattern.parser.NonTerminalEnum;
import fr.umlv.tatoo.cc.lexer.regex.pattern.parser.ProductionEnum;
import fr.umlv.tatoo.cc.lexer.regex.pattern.parser.TerminalEnum;
import fr.umlv.tatoo.runtime.parser.AcceptAction;
import fr.umlv.tatoo.runtime.parser.Action;
import fr.umlv.tatoo.runtime.parser.BranchAction;
import fr.umlv.tatoo.runtime.parser.ErrorAction;
import fr.umlv.tatoo.runtime.parser.ExitAction;
import fr.umlv.tatoo.runtime.parser.ParserTable;
import fr.umlv.tatoo.runtime.parser.ReduceAction;
import fr.umlv.tatoo.runtime.parser.ShiftAction;
import fr.umlv.tatoo.runtime.parser.StateMetadata;
import java.util.EnumMap;

/** 
 *  This class is generated - please do not edit it 
 */
public class ParserDataTable {
  private ParserDataTable() {
   accept = AcceptAction.<TerminalEnum,ProductionEnum,VersionEnum>getInstance();
   exit = ExitAction.<TerminalEnum,ProductionEnum,VersionEnum>getInstance();
    initstringGotoes();
    initintervalGotoes();
    initmainGotoes();
    inithatOptGotoes();
    initmacroGotoes();
    initspecialOrIntervalLetterGotoes();
    initspecialOrStringLetterGotoes();
    initregexGotoes();
    initspecialOrNormalLetterGotoes();
    initintervalsGotoes();
    initfollowGotoes();
    initpatternGotoes();
    reduceregexLetter = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regexLetter,1,regexGotoes);
    reduceregexIntervalNegate = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regexIntervalNegate,4,regexGotoes);
    reducespecialOrStringLetter = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.specialOrStringLetter,1,stringGotoes);
    reducemacro = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.macro,1,macroGotoes);
    reduceregexRange = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regexRange,6,regexGotoes);
    reducestringLetter = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.stringLetter,1,specialOrStringLetterGotoes);
    reducenormalLetter = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.normalLetter,1,specialOrNormalLetterGotoes);
    reduceregexPar = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regexPar,3,regexGotoes);
    reduceregexInterval = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regexInterval,3,regexGotoes);
    reduceinterval = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.interval,1,intervalsGotoes);
    reduceregexString = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regexString,3,regexGotoes);
    reduceregexPlus = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regexPlus,2,regexGotoes);
    reduceintervalSpecialLetter = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.intervalSpecialLetter,1,specialOrIntervalLetterGotoes);
    reducenormalSpecialLetter = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.normalSpecialLetter,1,specialOrNormalLetterGotoes);
    reduceregexAny = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regexAny,1,regexGotoes);
    reducestring = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.string,2,stringGotoes);
    reduceinitial = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.initial,3,patternGotoes);
    reducefollowRegex = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.followRegex,2,followGotoes);
    reduceregexTimes = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regexTimes,4,regexGotoes);
    reducehatEmpty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.hatEmpty,0,hatOptGotoes);
    reduceintervalLetter = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.intervalLetter,1,specialOrIntervalLetterGotoes);
    reduceregexMacro = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regexMacro,1,regexGotoes);
    reduceregexStar = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regexStar,2,regexGotoes);
    reducehatPresent = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.hatPresent,1,hatOptGotoes);
    reducemainRegex = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.mainRegex,1,mainGotoes);
    reduceintervalSet = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.intervalSet,3,intervalGotoes);
    reduceregexCat = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regexCat,2,regexGotoes);
    reducestringSpecialLetter = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.stringSpecialLetter,1,specialOrStringLetterGotoes);
    reduceregexOr = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regexOr,3,regexGotoes);
    reducefollowEmpty = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.followEmpty,0,followGotoes);
    reduceintervals = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.intervals,2,intervalsGotoes);
    reduceregexAtLeast = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regexAtLeast,5,regexGotoes);
    reduceintervalSingleton = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.intervalSingleton,1,intervalGotoes);
    reduceregexOptional = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.regexOptional,2,regexGotoes);
    reducefollowDollar = new ReduceAction<TerminalEnum,ProductionEnum,VersionEnum>(ProductionEnum.followDollar,1,followGotoes);
    shift11 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(11);
    shift37 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(37);
    shift46 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(46);
    shift32 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(32);
    shift15 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(15);
    shift50 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(50);
    shift12 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(12);
    shift4 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(4);
    shift14 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(14);
    shift39 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(39);
    shift35 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(35);
    shift25 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(25);
    shift6 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(6);
    shift1 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(1);
    shift36 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(36);
    shift31 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(31);
    shift49 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(49);
    shift3 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(3);
    shift29 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(29);
    shift13 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(13);
    shift10 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(10);
    shift18 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(18);
    shift34 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(34);
    shift28 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(28);
    shift30 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(30);
    shift21 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(21);
    shift27 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(27);
    shift33 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(33);
    shift9 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(9);
    shift2 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(2);
    shift24 = new ShiftAction<TerminalEnum,ProductionEnum,VersionEnum>(24);
    error0 = new ErrorAction<TerminalEnum,ProductionEnum,VersionEnum>("parse error");
    branch0 = new BranchAction<TerminalEnum,ProductionEnum,VersionEnum>("parse error");
    initdotArray();
    initlbracArray();
    initrparArray();
    init__eof__Array();
    initrbrakArray();
    initintegerArray();
    initquestionArray();
    initspecialLetterArray();
    initslashArray();
    initlbrakArray();
    initnameArray();
    initplusArray();
    inithatArray();
    initcommaArray();
    initquoteArray();
    initdollarArray();
    initnormalLetterArray();
    initintervalLetterArray();
    initstringLetterArray();
    initpipeArray();
    initminusArray();
    initlparArray();
    initrbracArray();
    initstarArray();
    EnumMap<TerminalEnum,Action<TerminalEnum,ProductionEnum,VersionEnum>[]> tableMap =
      new EnumMap<TerminalEnum,Action<TerminalEnum,ProductionEnum,VersionEnum>[]>(TerminalEnum.class);
      
    tableMap.put(TerminalEnum.dot,dotArray);
    tableMap.put(TerminalEnum.lbrac,lbracArray);
    tableMap.put(TerminalEnum.rpar,rparArray);
    tableMap.put(TerminalEnum.__eof__,__eof__Array);
    tableMap.put(TerminalEnum.rbrak,rbrakArray);
    tableMap.put(TerminalEnum.integer,integerArray);
    tableMap.put(TerminalEnum.question,questionArray);
    tableMap.put(TerminalEnum.specialLetter,specialLetterArray);
    tableMap.put(TerminalEnum.slash,slashArray);
    tableMap.put(TerminalEnum.lbrak,lbrakArray);
    tableMap.put(TerminalEnum.name,nameArray);
    tableMap.put(TerminalEnum.plus,plusArray);
    tableMap.put(TerminalEnum.hat,hatArray);
    tableMap.put(TerminalEnum.comma,commaArray);
    tableMap.put(TerminalEnum.quote,quoteArray);
    tableMap.put(TerminalEnum.dollar,dollarArray);
    tableMap.put(TerminalEnum.normalLetter,normalLetterArray);
    tableMap.put(TerminalEnum.intervalLetter,intervalLetterArray);
    tableMap.put(TerminalEnum.stringLetter,stringLetterArray);
    tableMap.put(TerminalEnum.pipe,pipeArray);
    tableMap.put(TerminalEnum.minus,minusArray);
    tableMap.put(TerminalEnum.lpar,lparArray);
    tableMap.put(TerminalEnum.rbrac,rbracArray);
    tableMap.put(TerminalEnum.star,starArray);
    initBranchArrayTable();
    
    StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>[] tableMetadata = createStateMetadataTable();
    
    EnumMap<NonTerminalEnum,Integer> tableStarts =
      new EnumMap<NonTerminalEnum,Integer>(NonTerminalEnum.class);
    tableStarts.put(NonTerminalEnum.macro,0);
    tableStarts.put(NonTerminalEnum.pattern,45);
    table = new ParserTable<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>(tableMap,branchArrayTable,tableMetadata,tableStarts,VersionEnum.values(),56,TerminalEnum.__eof__,null);
  } 

  // metadata aren't stored in local vars because it freak-out the register allocator of android
  @SuppressWarnings("unchecked")
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>[] createStateMetadataTable() {
        metadata0stringLetter_metadata0reducestringLetter = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.stringLetter,reducestringLetter);
    metadata0specialLetter_metadata0reduceintervalSpecialLetter = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.specialLetter,reduceintervalSpecialLetter);
    metadata0dot_metadata0reduceregexAny = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.dot,reduceregexAny);
    metadata0macro_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.macro,null);
    metadata0specialLetter_metadata0reducenormalSpecialLetter = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.specialLetter,reducenormalSpecialLetter);
    metadata0intervalLetter_metadata0reduceintervalLetter = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.intervalLetter,reduceintervalLetter);
    metadata0intervals_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.intervals,null);
    metadata0slash_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.slash,null);
    metadata0lpar_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.lpar,null);
    metadata0hatOpt_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.hatOpt,null);
    metadata0rbrac_metadata0reduceregexRange = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.rbrac,reduceregexRange);
    metadata0plus_metadata0reduceregexPlus = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.plus,reduceregexPlus);
    metadata0specialOrStringLetter_metadata0reducestring = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.specialOrStringLetter,reducestring);
    metadata0specialLetter_metadata0reducestringSpecialLetter = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.specialLetter,reducestringSpecialLetter);
    metadata0lbrac_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.lbrac,null);
    metadata0hat_metadata0reducehatPresent = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.hat,reducehatPresent);
    metadata0specialOrIntervalLetter_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.specialOrIntervalLetter,null);
    metadata0rbrak_metadata0reduceregexIntervalNegate = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.rbrak,reduceregexIntervalNegate);
    metadata0interval_metadata0reduceintervals = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.interval,reduceintervals);
    metadata0rbrac_metadata0reduceregexAtLeast = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.rbrac,reduceregexAtLeast);
    metadata0rpar_metadata0reduceregexPar = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.rpar,reduceregexPar);
    metadata0rbrac_metadata0reduceregexTimes = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.rbrac,reduceregexTimes);
    metadata0name_metadata0reduceregexMacro = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.name,reduceregexMacro);
    metadata0rbrak_metadata0reduceregexInterval = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.rbrak,reduceregexInterval);
    metadata0main_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.main,null);
    metadata0star_metadata0reduceregexStar = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.star,reduceregexStar);
    metadata0interval_metadata0reduceinterval = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.interval,reduceinterval);
    metadata0lbrak_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.lbrak,null);
    metadata0null_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(null,null);
    metadata0dollar_metadata0reducefollowDollar = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.dollar,reducefollowDollar);
    metadata0pipe_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.pipe,null);
    metadata0string_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.string,null);
    metadata0specialOrNormalLetter_metadata0reduceregexLetter = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.specialOrNormalLetter,reduceregexLetter);
    metadata0regex_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.regex,null);
    metadata0specialOrIntervalLetter_metadata0reduceintervalSet = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.specialOrIntervalLetter,reduceintervalSet);
    metadata0__eof___metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.__eof__,null);
    metadata0follow_metadata0reduceinitial = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.follow,reduceinitial);
    metadata0quote_metadata0reduceregexString = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.quote,reduceregexString);
    metadata0pattern_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.pattern,null);
    metadata0minus_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.minus,null);
    metadata0question_metadata0reduceregexOptional = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.question,reduceregexOptional);
    metadata0quote_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.quote,null);
    metadata0comma_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.comma,null);
    metadata0hat_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.hat,null);
    metadata0integer_metadata0null = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.integer,null);
    metadata0specialOrStringLetter_metadata0reducespecialOrStringLetter = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithNonTerminal(NonTerminalEnum.specialOrStringLetter,reducespecialOrStringLetter);
    metadata0normalLetter_metadata0reducenormalLetter = StateMetadata.<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>createAllVersionWithTerminal(TerminalEnum.normalLetter,reducenormalLetter);

    return (StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum>[])new StateMetadata<?,?,?,?>[]{metadata0null_metadata0null,metadata0dot_metadata0reduceregexAny,metadata0quote_metadata0null,metadata0specialLetter_metadata0reducestringSpecialLetter,metadata0stringLetter_metadata0reducestringLetter,metadata0string_metadata0null,metadata0quote_metadata0reduceregexString,metadata0specialOrStringLetter_metadata0reducestring,metadata0specialOrStringLetter_metadata0reducespecialOrStringLetter,metadata0normalLetter_metadata0reducenormalLetter,metadata0specialLetter_metadata0reducenormalSpecialLetter,metadata0lpar_metadata0null,metadata0lbrak_metadata0null,metadata0intervalLetter_metadata0reduceintervalLetter,metadata0specialLetter_metadata0reduceintervalSpecialLetter,metadata0hat_metadata0null,metadata0interval_metadata0reduceinterval,metadata0specialOrIntervalLetter_metadata0null,metadata0minus_metadata0null,metadata0specialOrIntervalLetter_metadata0reduceintervalSet,metadata0intervals_metadata0null,metadata0rbrak_metadata0reduceregexIntervalNegate,metadata0interval_metadata0reduceintervals,metadata0intervals_metadata0null,metadata0rbrak_metadata0reduceregexInterval,metadata0name_metadata0reduceregexMacro,metadata0regex_metadata0null,metadata0lbrac_metadata0null,metadata0integer_metadata0null,metadata0rbrac_metadata0reduceregexTimes,metadata0comma_metadata0null,metadata0integer_metadata0null,metadata0rbrac_metadata0reduceregexRange,metadata0rbrac_metadata0reduceregexAtLeast,metadata0rpar_metadata0reduceregexPar,metadata0question_metadata0reduceregexOptional,metadata0plus_metadata0reduceregexPlus,metadata0pipe_metadata0null,metadata0regex_metadata0null,metadata0star_metadata0reduceregexStar,metadata0regex_metadata0null,metadata0specialOrNormalLetter_metadata0reduceregexLetter,metadata0macro_metadata0null,metadata0__eof___metadata0null,metadata0regex_metadata0null,metadata0null_metadata0null,metadata0hat_metadata0reducehatPresent,metadata0hatOpt_metadata0null,metadata0main_metadata0null,metadata0dollar_metadata0reducefollowDollar,metadata0slash_metadata0null,metadata0regex_metadata0null,metadata0follow_metadata0reduceinitial,metadata0regex_metadata0null,metadata0pattern_metadata0null,metadata0__eof___metadata0null};
  }

  
  private int[] stringGotoes;

  private void initstringGotoes() {
    stringGotoes = 
      new int[]{-1,-1,5,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] intervalGotoes;

  private void initintervalGotoes() {
    intervalGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,16,-1,-1,16,-1,-1,-1,-1,22,-1,-1,22,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] mainGotoes;

  private void initmainGotoes() {
    mainGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,48,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] hatOptGotoes;

  private void inithatOptGotoes() {
    hatOptGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,47,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] macroGotoes;

  private void initmacroGotoes() {
    macroGotoes = 
      new int[]{42,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] specialOrIntervalLetterGotoes;

  private void initspecialOrIntervalLetterGotoes() {
    specialOrIntervalLetterGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,17,-1,-1,17,-1,-1,19,-1,17,-1,-1,17,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] specialOrStringLetterGotoes;

  private void initspecialOrStringLetterGotoes() {
    specialOrStringLetterGotoes = 
      new int[]{-1,-1,8,-1,-1,7,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] regexGotoes;

  private void initregexGotoes() {
    regexGotoes = 
      new int[]{44,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,26,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,40,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,38,40,-1,40,-1,-1,-1,40,-1,-1,53,-1,-1,51,40,-1,40,-1,-1};
  }
  
  private int[] specialOrNormalLetterGotoes;

  private void initspecialOrNormalLetterGotoes() {
    specialOrNormalLetterGotoes = 
      new int[]{41,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,41,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,41,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,41,41,-1,41,-1,-1,-1,41,-1,-1,41,-1,-1,41,41,-1,41,-1,-1};
  }
  
  private int[] intervalsGotoes;

  private void initintervalsGotoes() {
    intervalsGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,23,-1,-1,20,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] followGotoes;

  private void initfollowGotoes() {
    followGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,52,-1,-1,-1,-1,-1,-1,-1};
  }
  
  private int[] patternGotoes;

  private void initpatternGotoes() {
    patternGotoes = 
      new int[]{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,54,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
  }

  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] dotArray;
  @SuppressWarnings("unchecked")
  private void initdotArray() {
    dotArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{shift1,reduceregexAny,branch0,branch0,branch0,branch0,reduceregexString,branch0,branch0,reducenormalLetter,reducenormalSpecialLetter,shift1,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reduceregexIntervalNegate,branch0,branch0,reduceregexInterval,reduceregexMacro,shift1,branch0,branch0,reduceregexTimes,branch0,branch0,reduceregexRange,reduceregexAtLeast,reduceregexPar,reduceregexOptional,reduceregexPlus,shift1,shift1,reduceregexStar,reduceregexCat,reduceregexLetter,branch0,branch0,shift1,reducehatEmpty,reducehatPresent,shift1,branch0,branch0,shift1,shift1,branch0,shift1,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] lbracArray;
  @SuppressWarnings("unchecked")
  private void initlbracArray() {
    lbracArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,reduceregexAny,branch0,branch0,branch0,branch0,reduceregexString,branch0,branch0,reducenormalLetter,reducenormalSpecialLetter,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reduceregexIntervalNegate,branch0,branch0,reduceregexInterval,reduceregexMacro,shift27,branch0,branch0,reduceregexTimes,branch0,branch0,reduceregexRange,reduceregexAtLeast,reduceregexPar,reduceregexOptional,reduceregexPlus,branch0,shift27,reduceregexStar,shift27,reduceregexLetter,branch0,branch0,shift27,branch0,branch0,branch0,branch0,branch0,branch0,shift27,branch0,shift27,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] rparArray;
  @SuppressWarnings("unchecked")
  private void initrparArray() {
    rparArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,reduceregexAny,branch0,branch0,branch0,branch0,reduceregexString,branch0,branch0,reducenormalLetter,reducenormalSpecialLetter,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reduceregexIntervalNegate,branch0,branch0,reduceregexInterval,reduceregexMacro,shift34,branch0,branch0,reduceregexTimes,branch0,branch0,reduceregexRange,reduceregexAtLeast,reduceregexPar,reduceregexOptional,reduceregexPlus,branch0,reduceregexOr,reduceregexStar,reduceregexCat,reduceregexLetter,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] __eof__Array;
  @SuppressWarnings("unchecked")
  private void init__eof__Array() {
    __eof__Array=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,reduceregexAny,branch0,branch0,branch0,branch0,reduceregexString,branch0,branch0,reducenormalLetter,reducenormalSpecialLetter,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reduceregexIntervalNegate,branch0,branch0,reduceregexInterval,reduceregexMacro,branch0,branch0,branch0,reduceregexTimes,branch0,branch0,reduceregexRange,reduceregexAtLeast,reduceregexPar,reduceregexOptional,reduceregexPlus,branch0,reduceregexOr,reduceregexStar,reduceregexCat,reduceregexLetter,accept,accept,reducemacro,branch0,branch0,branch0,reducefollowEmpty,reducefollowDollar,branch0,reducefollowRegex,reduceinitial,reducemainRegex,accept,accept};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] rbrakArray;
  @SuppressWarnings("unchecked")
  private void initrbrakArray() {
    rbrakArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reduceintervalLetter,reduceintervalSpecialLetter,branch0,reduceinterval,reduceintervalSingleton,branch0,reduceintervalSet,shift21,branch0,reduceintervals,shift24,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] integerArray;
  @SuppressWarnings("unchecked")
  private void initintegerArray() {
    integerArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,shift28,branch0,branch0,shift31,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] questionArray;
  @SuppressWarnings("unchecked")
  private void initquestionArray() {
    questionArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,reduceregexAny,branch0,branch0,branch0,branch0,reduceregexString,branch0,branch0,reducenormalLetter,reducenormalSpecialLetter,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reduceregexIntervalNegate,branch0,branch0,reduceregexInterval,reduceregexMacro,shift35,branch0,branch0,reduceregexTimes,branch0,branch0,reduceregexRange,reduceregexAtLeast,reduceregexPar,reduceregexOptional,reduceregexPlus,branch0,shift35,reduceregexStar,shift35,reduceregexLetter,branch0,branch0,shift35,branch0,branch0,branch0,branch0,branch0,branch0,shift35,branch0,shift35,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] specialLetterArray;
  @SuppressWarnings("unchecked")
  private void initspecialLetterArray() {
    specialLetterArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{shift10,reduceregexAny,shift3,reducestringSpecialLetter,reducestringLetter,shift3,reduceregexString,reducestring,reducespecialOrStringLetter,reducenormalLetter,reducenormalSpecialLetter,shift10,shift14,reduceintervalLetter,reduceintervalSpecialLetter,shift14,reduceinterval,reduceintervalSingleton,shift14,reduceintervalSet,shift14,reduceregexIntervalNegate,reduceintervals,shift14,reduceregexInterval,reduceregexMacro,shift10,branch0,branch0,reduceregexTimes,branch0,branch0,reduceregexRange,reduceregexAtLeast,reduceregexPar,reduceregexOptional,reduceregexPlus,shift10,shift10,reduceregexStar,reduceregexCat,reduceregexLetter,branch0,branch0,shift10,reducehatEmpty,reducehatPresent,shift10,branch0,branch0,shift10,shift10,branch0,shift10,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] slashArray;
  @SuppressWarnings("unchecked")
  private void initslashArray() {
    slashArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,reduceregexAny,branch0,branch0,branch0,branch0,reduceregexString,branch0,branch0,reducenormalLetter,reducenormalSpecialLetter,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reduceregexIntervalNegate,branch0,branch0,reduceregexInterval,reduceregexMacro,branch0,branch0,branch0,reduceregexTimes,branch0,branch0,reduceregexRange,reduceregexAtLeast,reduceregexPar,reduceregexOptional,reduceregexPlus,branch0,reduceregexOr,reduceregexStar,reduceregexCat,reduceregexLetter,branch0,branch0,branch0,branch0,branch0,branch0,shift50,branch0,branch0,branch0,branch0,reducemainRegex,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] lbrakArray;
  @SuppressWarnings("unchecked")
  private void initlbrakArray() {
    lbrakArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{shift12,reduceregexAny,branch0,branch0,branch0,branch0,reduceregexString,branch0,branch0,reducenormalLetter,reducenormalSpecialLetter,shift12,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reduceregexIntervalNegate,branch0,branch0,reduceregexInterval,reduceregexMacro,shift12,branch0,branch0,reduceregexTimes,branch0,branch0,reduceregexRange,reduceregexAtLeast,reduceregexPar,reduceregexOptional,reduceregexPlus,shift12,shift12,reduceregexStar,reduceregexCat,reduceregexLetter,branch0,branch0,shift12,reducehatEmpty,reducehatPresent,shift12,branch0,branch0,shift12,shift12,branch0,shift12,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] nameArray;
  @SuppressWarnings("unchecked")
  private void initnameArray() {
    nameArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{shift25,reduceregexAny,branch0,branch0,branch0,branch0,reduceregexString,branch0,branch0,reducenormalLetter,reducenormalSpecialLetter,shift25,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reduceregexIntervalNegate,branch0,branch0,reduceregexInterval,reduceregexMacro,shift25,branch0,branch0,reduceregexTimes,branch0,branch0,reduceregexRange,reduceregexAtLeast,reduceregexPar,reduceregexOptional,reduceregexPlus,shift25,shift25,reduceregexStar,reduceregexCat,reduceregexLetter,branch0,branch0,shift25,reducehatEmpty,reducehatPresent,shift25,branch0,branch0,shift25,shift25,branch0,shift25,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] plusArray;
  @SuppressWarnings("unchecked")
  private void initplusArray() {
    plusArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,reduceregexAny,branch0,branch0,branch0,branch0,reduceregexString,branch0,branch0,reducenormalLetter,reducenormalSpecialLetter,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reduceregexIntervalNegate,branch0,branch0,reduceregexInterval,reduceregexMacro,shift36,branch0,branch0,reduceregexTimes,branch0,branch0,reduceregexRange,reduceregexAtLeast,reduceregexPar,reduceregexOptional,reduceregexPlus,branch0,shift36,reduceregexStar,shift36,reduceregexLetter,branch0,branch0,shift36,branch0,branch0,branch0,branch0,branch0,branch0,shift36,branch0,shift36,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] hatArray;
  @SuppressWarnings("unchecked")
  private void inithatArray() {
    hatArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,shift15,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,shift46,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] commaArray;
  @SuppressWarnings("unchecked")
  private void initcommaArray() {
    commaArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,shift30,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] quoteArray;
  @SuppressWarnings("unchecked")
  private void initquoteArray() {
    quoteArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{shift2,reduceregexAny,branch0,reducestringSpecialLetter,reducestringLetter,shift6,reduceregexString,reducestring,reducespecialOrStringLetter,reducenormalLetter,reducenormalSpecialLetter,shift2,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reduceregexIntervalNegate,branch0,branch0,reduceregexInterval,reduceregexMacro,shift2,branch0,branch0,reduceregexTimes,branch0,branch0,reduceregexRange,reduceregexAtLeast,reduceregexPar,reduceregexOptional,reduceregexPlus,shift2,shift2,reduceregexStar,reduceregexCat,reduceregexLetter,branch0,branch0,shift2,reducehatEmpty,reducehatPresent,shift2,branch0,branch0,shift2,shift2,branch0,shift2,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] dollarArray;
  @SuppressWarnings("unchecked")
  private void initdollarArray() {
    dollarArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,reduceregexAny,branch0,branch0,branch0,branch0,reduceregexString,branch0,branch0,reducenormalLetter,reducenormalSpecialLetter,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reduceregexIntervalNegate,branch0,branch0,reduceregexInterval,reduceregexMacro,branch0,branch0,branch0,reduceregexTimes,branch0,branch0,reduceregexRange,reduceregexAtLeast,reduceregexPar,reduceregexOptional,reduceregexPlus,branch0,reduceregexOr,reduceregexStar,reduceregexCat,reduceregexLetter,branch0,branch0,branch0,branch0,branch0,branch0,shift49,branch0,branch0,branch0,branch0,reducemainRegex,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] normalLetterArray;
  @SuppressWarnings("unchecked")
  private void initnormalLetterArray() {
    normalLetterArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{shift9,reduceregexAny,branch0,branch0,branch0,branch0,reduceregexString,branch0,branch0,reducenormalLetter,reducenormalSpecialLetter,shift9,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reduceregexIntervalNegate,branch0,branch0,reduceregexInterval,reduceregexMacro,shift9,branch0,branch0,reduceregexTimes,branch0,branch0,reduceregexRange,reduceregexAtLeast,reduceregexPar,reduceregexOptional,reduceregexPlus,shift9,shift9,reduceregexStar,reduceregexCat,reduceregexLetter,branch0,branch0,shift9,reducehatEmpty,reducehatPresent,shift9,branch0,branch0,shift9,shift9,branch0,shift9,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] intervalLetterArray;
  @SuppressWarnings("unchecked")
  private void initintervalLetterArray() {
    intervalLetterArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,shift13,reduceintervalLetter,reduceintervalSpecialLetter,shift13,reduceinterval,reduceintervalSingleton,shift13,reduceintervalSet,shift13,branch0,reduceintervals,shift13,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] stringLetterArray;
  @SuppressWarnings("unchecked")
  private void initstringLetterArray() {
    stringLetterArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,shift4,reducestringSpecialLetter,reducestringLetter,shift4,branch0,reducestring,reducespecialOrStringLetter,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] pipeArray;
  @SuppressWarnings("unchecked")
  private void initpipeArray() {
    pipeArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,reduceregexAny,branch0,branch0,branch0,branch0,reduceregexString,branch0,branch0,reducenormalLetter,reducenormalSpecialLetter,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reduceregexIntervalNegate,branch0,branch0,reduceregexInterval,reduceregexMacro,shift37,branch0,branch0,reduceregexTimes,branch0,branch0,reduceregexRange,reduceregexAtLeast,reduceregexPar,reduceregexOptional,reduceregexPlus,branch0,reduceregexOr,reduceregexStar,reduceregexCat,reduceregexLetter,branch0,branch0,shift37,branch0,branch0,branch0,branch0,branch0,branch0,shift37,branch0,shift37,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] minusArray;
  @SuppressWarnings("unchecked")
  private void initminusArray() {
    minusArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reduceintervalLetter,reduceintervalSpecialLetter,branch0,branch0,shift18,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] lparArray;
  @SuppressWarnings("unchecked")
  private void initlparArray() {
    lparArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{shift11,reduceregexAny,branch0,branch0,branch0,branch0,reduceregexString,branch0,branch0,reducenormalLetter,reducenormalSpecialLetter,shift11,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reduceregexIntervalNegate,branch0,branch0,reduceregexInterval,reduceregexMacro,shift11,branch0,branch0,reduceregexTimes,branch0,branch0,reduceregexRange,reduceregexAtLeast,reduceregexPar,reduceregexOptional,reduceregexPlus,shift11,shift11,reduceregexStar,reduceregexCat,reduceregexLetter,branch0,branch0,shift11,reducehatEmpty,reducehatPresent,shift11,branch0,branch0,shift11,shift11,branch0,shift11,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] rbracArray;
  @SuppressWarnings("unchecked")
  private void initrbracArray() {
    rbracArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,shift29,branch0,shift33,shift32,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0};
  }
  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] starArray;
  @SuppressWarnings("unchecked")
  private void initstarArray() {
    starArray=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{branch0,reduceregexAny,branch0,branch0,branch0,branch0,reduceregexString,branch0,branch0,reducenormalLetter,reducenormalSpecialLetter,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,branch0,reduceregexIntervalNegate,branch0,branch0,reduceregexInterval,reduceregexMacro,shift39,branch0,branch0,reduceregexTimes,branch0,branch0,reduceregexRange,reduceregexAtLeast,reduceregexPar,reduceregexOptional,reduceregexPlus,branch0,shift39,reduceregexStar,shift39,reduceregexLetter,branch0,branch0,shift39,branch0,branch0,branch0,branch0,branch0,branch0,shift39,branch0,shift39,branch0,branch0};
  }

  private Action<TerminalEnum,ProductionEnum,VersionEnum>[] branchArrayTable;
  @SuppressWarnings("unchecked")
  private void initBranchArrayTable() {
    branchArrayTable=(Action<TerminalEnum,ProductionEnum,VersionEnum>[])new Action<?,?,?>[]{error0,reduceregexAny,error0,error0,error0,error0,reduceregexString,error0,error0,reducenormalLetter,reducenormalSpecialLetter,error0,error0,error0,error0,error0,error0,error0,error0,error0,error0,reduceregexIntervalNegate,error0,error0,reduceregexInterval,reduceregexMacro,error0,error0,error0,reduceregexTimes,error0,error0,reduceregexRange,reduceregexAtLeast,reduceregexPar,reduceregexOptional,reduceregexPlus,error0,reduceregexOr,reduceregexStar,reduceregexCat,reduceregexLetter,exit,exit,reducemacro,error0,error0,error0,reducefollowEmpty,reducefollowDollar,error0,reducefollowRegex,reduceinitial,reducemainRegex,exit,exit};
  }

  private final ParserTable<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> table;
  
  public static final ParserTable<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> createTable() {
    return new ParserDataTable().table;
  }

  private final AcceptAction<TerminalEnum,ProductionEnum,VersionEnum> accept;
  private final ExitAction<TerminalEnum,ProductionEnum,VersionEnum> exit;

  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregexLetter;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregexIntervalNegate;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducespecialOrStringLetter;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducemacro;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregexRange;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducestringLetter;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducenormalLetter;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregexPar;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregexInterval;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceinterval;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregexString;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregexPlus;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceintervalSpecialLetter;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducenormalSpecialLetter;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregexAny;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducestring;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceinitial;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducefollowRegex;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregexTimes;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducehatEmpty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceintervalLetter;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregexMacro;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregexStar;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducehatPresent;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducemainRegex;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceintervalSet;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregexCat;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducestringSpecialLetter;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregexOr;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducefollowEmpty;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceintervals;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregexAtLeast;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceintervalSingleton;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reduceregexOptional;
  private final ReduceAction<TerminalEnum,ProductionEnum,VersionEnum> reducefollowDollar;

  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift11;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift37;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift46;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift32;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift15;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift50;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift12;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift4;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift14;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift39;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift35;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift25;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift6;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift1;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift36;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift31;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift49;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift3;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift29;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift13;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift10;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift18;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift34;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift28;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift30;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift21;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift27;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift33;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift9;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift2;
  private final ShiftAction<TerminalEnum,ProductionEnum,VersionEnum> shift24;


  private final ErrorAction<TerminalEnum,ProductionEnum,VersionEnum> error0;

  private final BranchAction<TerminalEnum,ProductionEnum,VersionEnum> branch0;


  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0stringLetter_metadata0reducestringLetter;
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0specialLetter_metadata0reduceintervalSpecialLetter;
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0dot_metadata0reduceregexAny;
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0macro_metadata0null;
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0specialLetter_metadata0reducenormalSpecialLetter;
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0intervalLetter_metadata0reduceintervalLetter;
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0intervals_metadata0null;
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0slash_metadata0null;
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0lpar_metadata0null;
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0hatOpt_metadata0null;
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0rbrac_metadata0reduceregexRange;
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0plus_metadata0reduceregexPlus;
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0specialOrStringLetter_metadata0reducestring;
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0specialLetter_metadata0reducestringSpecialLetter;
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0lbrac_metadata0null;
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0hat_metadata0reducehatPresent;
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0specialOrIntervalLetter_metadata0null;
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0rbrak_metadata0reduceregexIntervalNegate;
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0interval_metadata0reduceintervals;
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0rbrac_metadata0reduceregexAtLeast;
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0rpar_metadata0reduceregexPar;
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0rbrac_metadata0reduceregexTimes;
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0name_metadata0reduceregexMacro;
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0rbrak_metadata0reduceregexInterval;
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0main_metadata0null;
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0star_metadata0reduceregexStar;
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0interval_metadata0reduceinterval;
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0lbrak_metadata0null;
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0null_metadata0null;
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0dollar_metadata0reducefollowDollar;
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0pipe_metadata0null;
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0string_metadata0null;
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0specialOrNormalLetter_metadata0reduceregexLetter;
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0regex_metadata0null;
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0specialOrIntervalLetter_metadata0reduceintervalSet;
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0__eof___metadata0null;
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0follow_metadata0reduceinitial;
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0quote_metadata0reduceregexString;
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0pattern_metadata0null;
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0minus_metadata0null;
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0question_metadata0reduceregexOptional;
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0quote_metadata0null;
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0comma_metadata0null;
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0hat_metadata0null;
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0integer_metadata0null;
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0specialOrStringLetter_metadata0reducespecialOrStringLetter;
  private StateMetadata<TerminalEnum,NonTerminalEnum,ProductionEnum,VersionEnum> metadata0normalLetter_metadata0reducenormalLetter;
}
