package fr.umlv.tatoo.cc.lexer.regex.pattern.lexer;

/** 
 *  This class is generated - please do not edit it 
 */
public enum RuleEnum {
dot,
hat,
quote,
comma,
star,
plus,
minus,
slash,
dollar,
question,
lbrak,
rbrak,
lbrac,
rbrac,
lpar,
rpar,
pipe,
eoln,
cr,
formfeed,
tab,
backspace,
unicodeChar,
escapedChar,
stringEscapedChar,
intervalEscapedChar,
normalChar,
stringChar,
intervalChar,
integer,
macro;
}
