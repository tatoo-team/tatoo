package fr.umlv.tatoo.cc.common.main;

public interface AliasPrototype {
  public String name();
  public String getDefaultTypeName();
  public Unit getUnit();
}
