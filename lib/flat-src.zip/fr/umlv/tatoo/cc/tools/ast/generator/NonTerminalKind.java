package fr.umlv.tatoo.cc.tools.ast.generator;

public enum NonTerminalKind {
  USER_DEFINED,
  EBNF_DEFINED,
  HAS_ONE_PRODUCTION
}
