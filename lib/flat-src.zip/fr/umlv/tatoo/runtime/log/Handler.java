package fr.umlv.tatoo.runtime.log;

public interface Handler {
  void print(Object object);
}
